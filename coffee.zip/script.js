// script.js

// Toggle search form visibility
let searchForm = document.querySelector('.search-form');
let cartItemContainer = document.querySelector('.cart-item-container');
let navbar = document.querySelector('.navbar');

function toggleNavbar() {
    document.querySelector('.navbar').classList.toggle('active');
}


// Toggle search form visibility
document.querySelector('#search-btn').onclick = () => {
    searchForm.classList.toggle('active');
    navbar.classList.remove('active');
    cartItemContainer.classList.remove('active');
    
}


// Toggle cart item container visibility
document.querySelector('#cart-btn').onclick = () => {
    cartItemContainer.classList.toggle('active');
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
}

document.querySelector('#menu-btn').onclick = () =>{
    navbar.classList.toggle('active');
    searchForm.classList.remove('active');
    cartItemContainer.classList.remove('active');

}


window.onscroll = () =>{
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
    cartItemContainer.classList.remove('active');
}